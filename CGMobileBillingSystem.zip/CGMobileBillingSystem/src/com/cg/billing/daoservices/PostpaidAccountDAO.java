package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;

public interface PostpaidAccountDAO {
	PostpaidAccount save(PostpaidAccount postpaidaccount);
	boolean update(PostpaidAccount postpaidaccount);
	Plan findOne(int postpaidaccountID);
	List<PostpaidAccount> findAll();
}
