package com.cg.billing.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;

public class PostpaidAccountDAOImpl implements PostpaidAccountDAO{
	
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
	
	@Override
	public PostpaidAccount save(PostpaidAccount postpaidaccount) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(postpaidaccount);
		entityManager.getTransaction().commit();
		entityManager.close();
		return postpaidaccount;
	}

	@Override
	public boolean update(PostpaidAccount postpaidaccount) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(postpaidaccount);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

	@Override
	public Plan findOne(int postpaidaccountID) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Plan.class, postpaidaccountID);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PostpaidAccount> findAll() {
		Query query=entityManagerFactory.createEntityManager().createQuery("from Associate a");
		return (List<PostpaidAccount>)query.getResultList();
	}

}
