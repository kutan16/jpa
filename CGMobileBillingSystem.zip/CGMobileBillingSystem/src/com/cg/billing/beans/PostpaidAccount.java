package com.cg.billing.beans;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class PostpaidAccount {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long mobileNo;
	@ManyToOne
	private Plan plan;
	@ManyToOne
	private Customer customer;
	@OneToOne
	private Map<Integer, Bill> bills = new HashMap<>();
	public PostpaidAccount() {}

	}