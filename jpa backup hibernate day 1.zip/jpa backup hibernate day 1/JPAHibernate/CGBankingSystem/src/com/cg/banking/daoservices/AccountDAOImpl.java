package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;

public  class AccountDAOImpl implements AccountDAO{

//	private static Connection con = BankingDBUtil.getDBConnection();
//	@Override
//	public Account save(Account account) {
//		try {
//			con.setAutoCommit(false);
//
//			PreparedStatement pstmt1 = con.prepareStatement("insert into Account(accountno,pinnumber,accounttype,accountstatus,accountbalance) values(account_id_seq.nextval,account_pin_seq.nextval,?,?,?)");
//			//pstmt1.setInt(1, associate.getAssociateId());
//			pstmt1.setString(1, account.getAccountType());
//			pstmt1.setFloat(2, account.getAccountBalance());
//			pstmt1.setString(3, account.setAccountStatus("active"));			
//
//			pstmt1.executeUpdate();
//			con.commit();
//		}
//		catch(SQLException e) {
//			e.printStackTrace();
//			try{
//				con.rollback();
//			}
//			catch (SQLException e1) {
//				e1.printStackTrace();
//			}
//		}
//		return account;
//	}
//
//	@Override
//	public boolean update(Account account) {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	@Override
//	public Account findOne(long accountNo) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public List<Account> findAll() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public Account save(Account account) {
		account.setAccountNo(BankingDBUtil.getACCOUNT_ID_COUNTER());
		account.setAccountStatus(BankingDBUtil.getAccountStatus());
		account.setPinNumber(BankingDBUtil.getPin());
		BankingDBUtil.accountDetails.put(account.getAccountNo(),account);
		BankingDBUtil.accountDetails.put((long) account.getPinNumber(), account);
		return account;
	}
	@Override
	public boolean update(Account account) {
		return false;
	}
	@Override
	public Account findOne(long accountNo) {
		return BankingDBUtil.accountDetails.get(accountNo);
	}
	@Override
	public List<Account> findAll() {
		return new ArrayList<Account>(BankingDBUtil.accountDetails.values());
	}
	
	



}