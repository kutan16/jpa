package com.cg.ticketing.daoservices;

import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.beans.UnReservedTicket;

public interface UnReservedBookingDAO {
	//String book(UnReservedTicket unReservedTicket);
	//ReservedTicket save(String ticketId);
	UnReservedTicket save(UnReservedTicket ticketId);
	UnReservedTicket findOne(UnReservedTicket ticketId);
	UnReservedTicket delete(UnReservedTicket ticketId);
}
