package com.cg.ticketing.beans;

public class UnReservedTicket {
	int ticketId;
	private String arrivalStation,departureStation;
	int price;
	public UnReservedTicket() {}
	public UnReservedTicket(int ticketId, String arrivalStation, String departureStation, int price) {
		super();
		this.ticketId = ticketId;
		this.arrivalStation = arrivalStation;
		this.departureStation = departureStation;
		this.price = price;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((arrivalStation == null) ? 0 : arrivalStation.hashCode());
		result = prime * result + ((departureStation == null) ? 0 : departureStation.hashCode());
		result = prime * result + price;
		result = prime * result + ticketId;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UnReservedTicket other = (UnReservedTicket) obj;
		if (arrivalStation == null) {
			if (other.arrivalStation != null)
				return false;
		} else if (!arrivalStation.equals(other.arrivalStation))
			return false;
		if (departureStation == null) {
			if (other.departureStation != null)
				return false;
		} else if (!departureStation.equals(other.departureStation))
			return false;
		if (price != other.price)
			return false;
		if (ticketId != other.ticketId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "UnReservedTicket [ticketId=" + ticketId + ", arrivalStation=" + arrivalStation + ", departureStation="
				+ departureStation + ", price=" + price + "]";
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public String getArrivalStation() {
		return arrivalStation;
	}
	public void setArrivalStation(String arrivalStation) {
		this.arrivalStation = arrivalStation;
	}
	public String getDepartureStation() {
		return departureStation;
	}
	public void setDepartureStation(String departureStation) {
		this.departureStation = departureStation;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
}
