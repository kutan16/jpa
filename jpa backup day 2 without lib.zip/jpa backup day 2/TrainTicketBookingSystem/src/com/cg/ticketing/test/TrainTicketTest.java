package com.cg.ticketing.test;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import com.cg.ticketing.services.TicketingServices;
import com.cg.ticketing.services.TicketingServicesImpl;
public class TrainTicketTest {
	private static TicketingServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new TicketingServicesImpl();
	}
	@AfterClass
public static void tearDownTestEnv() {
	services=null;
}
}
